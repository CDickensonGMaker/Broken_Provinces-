## crime_manager.gd - Manages player bounties and crime system
## Tracks bounties per region, handles crime reporting, and coordinates with guards
extends Node

## Signals
signal bounty_changed(region_id: String, new_amount: int)
signal player_arrested(region_id: String)
signal player_jailed(region_id: String)
signal player_released(region_id: String)
signal crime_reported(crime_type: CrimeType, region_id: String)

## Crime types
enum CrimeType {
	ASSAULT,      # Attacking an NPC
	THEFT,        # Stealing from a chest/container
	MURDER,       # Killing an NPC
	TRESPASSING,  # Breaking into a locked area
	PICKPOCKET    # Pickpocketing an NPC
}

## Base bounty values per crime type
const BOUNTY_VALUES: Dictionary = {
	CrimeType.ASSAULT: 100,
	CrimeType.THEFT: 50,
	CrimeType.MURDER: 1000,
	CrimeType.TRESPASSING: 25,
	CrimeType.PICKPOCKET: 40
}

## Crime names for display
const CRIME_NAMES: Dictionary = {
	CrimeType.ASSAULT: "Assault",
	CrimeType.THEFT: "Theft",
	CrimeType.MURDER: "Murder",
	CrimeType.TRESPASSING: "Trespassing",
	CrimeType.PICKPOCKET: "Pickpocketing"
}

## Reputation penalties per crime type (applied to town faction)
const REPUTATION_PENALTIES: Dictionary = {
	CrimeType.ASSAULT: -10,
	CrimeType.THEFT: -5,
	CrimeType.MURDER: -25,
	CrimeType.TRESPASSING: -3,
	CrimeType.PICKPOCKET: -5
}

## Bounty tracking per region
## Format: { "region_id": bounty_amount }
var bounties: Dictionary = {}

## Last known crimes per region (for guard dialogue)
## Format: { "region_id": CrimeType }
var last_crimes: Dictionary = {}

## Jailed weapons storage (items confiscated when jailed)
## Format: { "region_id": [{item_id, quality, data, durability, max_durability}] }
var confiscated_items: Dictionary = {}

## Whether player is currently jailed
var is_jailed: bool = false

## Current jail region (while jailed)
var jail_region: String = ""

## Time remaining in jail (in game hours)
var jail_time_remaining: float = 0.0

## Return scene/position tracking (for returning after jail)
var return_scene: String = ""
var return_position: Vector3 = Vector3.ZERO

## Bounty to time conversion rate (gold per game hour)
const BOUNTY_PER_HOUR: int = 100


func _ready() -> void:
	print("[CrimeManager] Initialized")

	# Connect to scene load to validate jail state
	if SceneManager:
		SceneManager.scene_load_completed.connect(_on_scene_loaded)

	# Connect to time advanced signal (for hard waiting while in jail)
	if GameManager:
		GameManager.time_advanced.connect(_on_time_advanced)


## Validate jail state when scene loads - fix corrupted save data
func _on_scene_loaded(scene_path: String) -> void:
	if is_jailed and not scene_path.contains("prison"):
		push_warning("[CrimeManager] Clearing invalid jail state - was jailed but loaded into %s" % scene_path)
		is_jailed = false
		jail_region = ""
		jail_time_remaining = 0.0
		confiscated_items.clear()


## Handle time being advanced via waiting/resting (decreases jail time)
func _on_time_advanced(hours: float) -> void:
	if is_jailed and jail_time_remaining > 0.0:
		jail_time_remaining -= hours
		print("[CrimeManager] Jail time decreased by %.1f hours, %.1f remaining" % [hours, jail_time_remaining])

		if jail_time_remaining <= 0.0:
			_release_from_jail()


func _process(delta: float) -> void:
	if is_jailed and jail_time_remaining > 0.0:
		# Convert real delta to game hours
		var hours_passed: float = (delta * GameManager.time_scale) / 3600.0
		jail_time_remaining -= hours_passed

		if jail_time_remaining <= 0.0:
			_release_from_jail()


## Report a crime
## crime_type: The type of crime committed
## region_id: The region where the crime occurred
## witnesses: Array of witness nodes (NPCs who saw the crime) - if empty, auto-finds nearby NPCs
## crime_position: Optional position where crime occurred (for witness finding)
## Returns: true if crime was successfully reported (had witnesses)
func report_crime(crime_type: CrimeType, region_id: String, witnesses: Array = [], crime_position: Vector3 = Vector3.ZERO) -> bool:
	# If no witnesses provided, try to find nearby NPCs
	if witnesses.is_empty():
		witnesses = _find_nearby_witnesses(crime_position)

	# No witnesses = no crime reported
	if witnesses.is_empty():
		print("[CrimeManager] Crime committed but no witnesses")
		return false

	# Get bounty value for this crime
	var bounty_value: int = BOUNTY_VALUES.get(crime_type, 50)

	# Add to existing bounty
	var current_bounty: int = bounties.get(region_id, 0)
	bounties[region_id] = current_bounty + bounty_value
	last_crimes[region_id] = crime_type

	print("[CrimeManager] Crime reported: %s in %s (+%d bounty, total: %d) - %d witnesses" % [
		CRIME_NAMES.get(crime_type, "Unknown"),
		region_id,
		bounty_value,
		bounties[region_id],
		witnesses.size()
	])

	# Emit signal for UI updates
	bounty_changed.emit(region_id, bounties[region_id])
	crime_reported.emit(crime_type, region_id)

	# Alert nearby guards
	_alert_guards(region_id)

	# Affect disposition with witnesses
	_affect_witness_disposition(witnesses, crime_type)

	# Apply reputation penalty to town faction
	_apply_faction_reputation_penalty(crime_type, region_id)

	# Show notification
	_show_crime_notification(crime_type, witnesses.size())

	return true


## Find nearby NPCs who could witness a crime
## Returns array of NPCs within witness range
func _find_nearby_witnesses(crime_position: Vector3) -> Array:
	var witnesses: Array = []
	var witness_range: float = 20.0  # How far NPCs can see crimes

	# If no position given, use player position
	if crime_position == Vector3.ZERO:
		var player: Node = get_tree().get_first_node_in_group("player")
		if player and player is Node3D:
			crime_position = (player as Node3D).global_position

	if crime_position == Vector3.ZERO:
		return witnesses

	# Find all NPCs in range
	var npcs: Array = get_tree().get_nodes_in_group("npcs")
	for npc in npcs:
		if not is_instance_valid(npc):
			continue
		if not npc is Node3D:
			continue

		# Skip dead NPCs
		if npc.has_method("is_dead") and npc.is_dead():
			continue

		var distance: float = (npc as Node3D).global_position.distance_to(crime_position)
		if distance <= witness_range:
			witnesses.append(npc)

	return witnesses


## Reduce disposition with NPCs who witnessed the crime
func _affect_witness_disposition(witnesses: Array, crime_type: CrimeType) -> void:
	var disposition_penalty: int = 0
	match crime_type:
		CrimeType.ASSAULT:
			disposition_penalty = -20
		CrimeType.THEFT:
			disposition_penalty = -10
		CrimeType.MURDER:
			disposition_penalty = -50
		CrimeType.TRESPASSING:
			disposition_penalty = -5
		CrimeType.PICKPOCKET:
			disposition_penalty = -10

	for witness in witnesses:
		if not is_instance_valid(witness):
			continue

		# Set a flag that this NPC saw the player commit a crime
		var npc_id: String = ""
		if "npc_id" in witness:
			npc_id = witness.npc_id
		elif witness.has_method("get_npc_id"):
			npc_id = witness.get_npc_id()

		if not npc_id.is_empty():
			# Store witness info in ConversationSystem flags
			ConversationSystem.set_flag(npc_id + "_witnessed_crime", true)
			ConversationSystem.set_flag(npc_id + "_witnessed_" + CRIME_NAMES.get(crime_type, "crime").to_lower(), true)

			# Reduce disposition
			if witness.has_method("modify_disposition"):
				witness.modify_disposition(disposition_penalty)
			elif "base_disposition" in witness:
				witness.base_disposition = maxi(0, witness.base_disposition + disposition_penalty)


## Show notification about crime being witnessed
func _show_crime_notification(crime_type: CrimeType, witness_count: int) -> void:
	var hud: Node = get_tree().get_first_node_in_group("hud")
	if hud and hud.has_method("show_notification"):
		var crime_name: String = CRIME_NAMES.get(crime_type, "Crime")
		if witness_count > 0:
			hud.show_notification("%s witnessed! Bounty added." % crime_name)
		else:
			hud.show_notification("%s committed." % crime_name)


## Get current bounty in a region
func get_bounty(region_id: String) -> int:
	return bounties.get(region_id, 0)


## Get total bounty across all regions
func get_total_bounty() -> int:
	var total := 0
	for region_id in bounties.keys():
		total += bounties[region_id]
	return total


## Check if player has any bounty in the current region
func has_bounty_in_region(region_id: String) -> bool:
	return get_bounty(region_id) > 0


## Check if player has any bounty anywhere
func has_any_bounty() -> bool:
	return get_total_bounty() > 0


## Get the name of the last crime committed in a region
func get_last_crime_name(region_id: String) -> String:
	if not last_crimes.has(region_id):
		return "crimes"
	return CRIME_NAMES.get(last_crimes[region_id], "crimes")


## Pay bounty with gold to clear it
## Returns: true if payment successful
func pay_bounty(region_id: String) -> bool:
	var bounty: int = get_bounty(region_id)
	if bounty <= 0:
		return true  # No bounty to pay

	if not InventoryManager.remove_gold(bounty):
		push_warning("[CrimeManager] Not enough gold to pay bounty")
		return false

	bounties[region_id] = 0
	last_crimes.erase(region_id)

	print("[CrimeManager] Bounty paid: %d gold in %s" % [bounty, region_id])
	bounty_changed.emit(region_id, 0)

	return true


## Calculate jail time for current bounty (in game hours)
func calculate_jail_time(region_id: String) -> float:
	var bounty: int = get_bounty(region_id)
	@warning_ignore("integer_division")
	return float(bounty) / float(BOUNTY_PER_HOUR)


## Serve jail time to clear bounty
## This initiates the jailing process - player is teleported to jail
func serve_time(region_id: String) -> void:
	var bounty: int = get_bounty(region_id)
	if bounty <= 0:
		return

	is_jailed = true
	jail_region = region_id
	jail_time_remaining = calculate_jail_time(region_id)

	# Confiscate equipped weapons
	_confiscate_weapons(region_id)

	print("[CrimeManager] Player jailed in %s for %.1f hours" % [region_id, jail_time_remaining])
	player_jailed.emit(region_id)


## Set bounty to a specific value (for negotiations, partial payments)
func set_bounty(region_id: String, amount: int) -> void:
	var old_bounty: int = bounties.get(region_id, 0)
	bounties[region_id] = maxi(0, amount)
	if bounties[region_id] == 0:
		last_crimes.erase(region_id)
	bounty_changed.emit(region_id, bounties[region_id])
	print("[CrimeManager] Bounty in %s set to %d (was %d)" % [region_id, bounties[region_id], old_bounty])


## Clear bounty (for pardons, escapes, or completing jail time)
func clear_bounty(region_id: String) -> void:
	if bounties.has(region_id):
		bounties[region_id] = 0
		last_crimes.erase(region_id)
		bounty_changed.emit(region_id, 0)
		print("[CrimeManager] Bounty cleared in %s" % region_id)


## Clear all bounties (for pardons or special events)
func clear_all_bounties() -> void:
	for region_id in bounties.keys():
		clear_bounty(region_id)


## Alert guards in the region about the crime
func _alert_guards(region_id: String) -> void:
	var guards := get_tree().get_nodes_in_group("guards")
	for guard in guards:
		if guard.has_method("on_crime_reported"):
			guard.on_crime_reported(region_id)


## Apply reputation penalty to the appropriate town faction
func _apply_faction_reputation_penalty(crime_type: CrimeType, _region_id: String) -> void:
	if not FactionManager:
		return

	# Get the town faction for the current location
	var town_faction: String = FactionManager.get_town_faction()
	if town_faction.is_empty():
		# Not in a town with a faction - no reputation penalty
		return

	# Get the penalty for this crime type
	var penalty: int = REPUTATION_PENALTIES.get(crime_type, -5)

	# Apply reputation change with cascading (mark as crime for time decay tracking)
	var crime_name: String = CRIME_NAMES.get(crime_type, "crime")
	FactionManager.modify_reputation(town_faction, penalty, "committed %s" % crime_name, true, true)

	print("[CrimeManager] Applied %d reputation penalty to %s for %s" % [penalty, town_faction, crime_name])


## Confiscate player's equipped weapons when jailed
func _confiscate_weapons(region_id: String) -> void:
	var confiscated: Array = []

	# Get main hand weapon
	if not InventoryManager.equipment.main_hand.is_empty():
		var weapon: Dictionary = InventoryManager.equipment.main_hand.duplicate()
		confiscated.append(weapon)
		InventoryManager.equipment.main_hand = {}
		print("[CrimeManager] Confiscated main hand: %s" % weapon.get("item_id", "unknown"))

	# Get off hand (shield/secondary)
	if not InventoryManager.equipment.off_hand.is_empty():
		var off_hand: Dictionary = InventoryManager.equipment.off_hand.duplicate()
		confiscated.append(off_hand)
		InventoryManager.equipment.off_hand = {}
		print("[CrimeManager] Confiscated off hand: %s" % off_hand.get("item_id", "unknown"))

	confiscated_items[region_id] = confiscated


## Return confiscated items to player on release
func _return_confiscated_items(region_id: String) -> void:
	if not confiscated_items.has(region_id):
		return

	var items: Array = confiscated_items[region_id]
	for item in items:
		var item_id: String = item.get("item_id", "")
		var quality: Enums.ItemQuality = item.get("quality", Enums.ItemQuality.AVERAGE)

		if not item_id.is_empty():
			InventoryManager.add_item(item_id, 1, quality)
			print("[CrimeManager] Returned confiscated item: %s" % item_id)

	confiscated_items.erase(region_id)


## Release player from jail after serving time
func _release_from_jail() -> void:
	if not is_jailed:
		return

	var region: String = jail_region

	# Clear bounty
	clear_bounty(region)

	# Return confiscated items
	_return_confiscated_items(region)

	# Reset jail state
	is_jailed = false
	jail_region = ""
	jail_time_remaining = 0.0

	print("[CrimeManager] Player released from jail in %s" % region)
	player_released.emit(region)


## Called when player escapes from jail (bounty not cleared, adds to it)
func on_jail_escape(region_id: String) -> void:
	# Add escape bounty (treated as trespassing)
	var escape_bounty: int = 200  # Escaping jail is serious
	var current_bounty: int = bounties.get(region_id, 0)
	bounties[region_id] = current_bounty + escape_bounty

	print("[CrimeManager] Jail escape! Additional bounty: %d" % escape_bounty)
	bounty_changed.emit(region_id, bounties[region_id])

	# Return items (player managed to grab them)
	_return_confiscated_items(region_id)

	# Reset jail state
	is_jailed = false
	jail_region = ""
	jail_time_remaining = 0.0


## Skip jail time (for testing or time-skip mechanics)
func skip_jail_time() -> void:
	if is_jailed:
		jail_time_remaining = 0.0
		_release_from_jail()


## Serialize for saving
func to_dict() -> Dictionary:
	return {
		"bounties": bounties.duplicate(),
		"last_crimes": last_crimes.duplicate(),
		"confiscated_items": confiscated_items.duplicate(true),
		"is_jailed": is_jailed,
		"jail_region": jail_region,
		"jail_time_remaining": jail_time_remaining,
		"return_scene": return_scene,
		"return_position": {"x": return_position.x, "y": return_position.y, "z": return_position.z}
	}


## Deserialize from save
func from_dict(data: Dictionary) -> void:
	bounties = data.get("bounties", {}).duplicate()
	last_crimes = data.get("last_crimes", {}).duplicate()
	confiscated_items = data.get("confiscated_items", {}).duplicate(true)
	is_jailed = data.get("is_jailed", false)
	jail_region = data.get("jail_region", "")
	jail_time_remaining = data.get("jail_time_remaining", 0.0)
	return_scene = data.get("return_scene", "")
	var pos_data: Dictionary = data.get("return_position", {})
	if not pos_data.is_empty():
		return_position = Vector3(pos_data.get("x", 0.0), pos_data.get("y", 0.0), pos_data.get("z", 0.0))
	else:
		return_position = Vector3.ZERO


## Reset for new game
func reset_for_new_game() -> void:
	bounties.clear()
	last_crimes.clear()
	confiscated_items.clear()
	is_jailed = false
	jail_region = ""
	jail_time_remaining = 0.0
	return_scene = ""
	return_position = Vector3.ZERO
