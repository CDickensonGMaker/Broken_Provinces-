## bandit_hideout_level_2.gd - Bandit Hideout Level 2 (Hand-crafted)
## Bandit leader's lair and treasure vault
## All geometry, enemies, chests, and doors are pre-placed in the .tscn file
extends Node3D

const ZONE_ID := "bandit_hideout_level_2"

var spawn_points: Node3D
var enemy_spawns: Node3D
var door_positions: Node3D
var chest_positions: Node3D


func _ready() -> void:
	# Get optional nodes (may not exist in scene)
	# Note: Scene uses EnemySpawns, DoorPositions, ChestPositions naming convention
	spawn_points = get_node_or_null("SpawnPoints")
	enemy_spawns = get_node_or_null("EnemySpawns")
	door_positions = get_node_or_null("DoorPositions")
	chest_positions = get_node_or_null("ChestPositions")

	SaveManager.set_current_zone(ZONE_ID, "Bandit Hideout - Boss Lair")

	# Play dungeon music
	AudioManager.play_zone_music("dungeon")

	_setup_environment()
	_setup_spawn_points()
	_setup_enemies()
	_setup_doors()
	_setup_chests()
	_setup_navigation()

	print("[BanditHideoutL2] Hand-crafted level loaded")


func _setup_environment() -> void:
	# Check if WorldEnvironment already exists in scene
	if has_node("WorldEnvironment"):
		return

	# Create environment if not pre-placed
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.05, 0.035, 0.025)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.22, 0.16, 0.1)
	env.ambient_light_energy = 0.4
	env.fog_enabled = true
	env.fog_light_color = Color(0.1, 0.06, 0.03)
	env.fog_density = 0.015

	var world_env := WorldEnvironment.new()
	world_env.name = "WorldEnvironment"
	world_env.environment = env
	add_child(world_env)

	# Add directional light if not present
	if not has_node("DirectionalLight3D"):
		var light := DirectionalLight3D.new()
		light.name = "DirectionalLight3D"
		light.light_color = Color(1.0, 0.8, 0.55)
		light.light_energy = 0.08
		light.rotation_degrees = Vector3(-45, 30, 0)
		add_child(light)


func _setup_spawn_points() -> void:
	# Look for pre-placed spawn points in scene
	# Expected structure: SpawnPoints/SpawnPoint_Default, SpawnPoints/SpawnPoint_FromLevel1, etc.

	if not spawn_points:
		spawn_points = get_node_or_null("SpawnPoints")

	if spawn_points:
		for child in spawn_points.get_children():
			child.add_to_group("spawn_points")
			# Extract spawn_id from node name (e.g., "SpawnPoint_FromLevel1" -> "fromlevel1")
			var spawn_id := child.name.replace("SpawnPoint_", "").to_lower()
			child.set_meta("spawn_id", spawn_id)
		print("[BanditHideoutL2] Found %d pre-placed spawn points" % spawn_points.get_child_count())
	else:
		# Create default spawn point if none exist
		push_warning("[BanditHideoutL2] No SpawnPoints node found, creating default")
		var default_spawn := Node3D.new()
		default_spawn.name = "SpawnPoint_Default"
		default_spawn.add_to_group("spawn_points")
		default_spawn.set_meta("spawn_id", "default")
		default_spawn.global_position = Vector3(0, 0.5, 0)
		add_child(default_spawn)


func _setup_enemies() -> void:
	# Look for pre-placed enemy markers in scene
	# Expected structure: EnemySpawns/Marker3D nodes with metadata
	# For boss: set metadata "enemy_data" to "res://data/enemies/bandit_leader.tres"

	if not enemy_spawns:
		enemy_spawns = get_node_or_null("EnemySpawns")

	if not enemy_spawns:
		return

	var enemy_count := 0
	for marker in enemy_spawns.get_children():
		if marker is Marker3D or marker is Node3D:
			_spawn_enemy_at_marker(marker)
			enemy_count += 1

	print("[BanditHideoutL2] Spawned %d enemies from markers" % enemy_count)


func _spawn_enemy_at_marker(marker: Node3D) -> void:
	# Get enemy configuration from marker metadata or use defaults
	var enemy_data_path: String = marker.get_meta("enemy_data", "res://data/enemies/human_bandit.tres")
	var is_boss: bool = marker.get_meta("is_boss", false)

	# Extract enemy type ID from path (e.g., "human_bandit" from ".../human_bandit.tres")
	var enemy_type: String = enemy_data_path.get_file().get_basename()

	# Check ActorRegistry first for sprite config (includes zoo patches)
	var sprite_config: Dictionary = ActorRegistry.get_sprite_config(enemy_type)

	var sprite_path: String
	var h_frames: int
	var v_frames: int

	if not sprite_config.is_empty():
		# Use ActorRegistry values (includes zoo patches)
		sprite_path = sprite_config.get("sprite_path", "")
		h_frames = sprite_config.get("h_frames", 4)
		v_frames = sprite_config.get("v_frames", 1)
	else:
		# Fall back to marker metadata
		sprite_path = marker.get_meta("sprite_path", "res://assets/sprites/enemies/humanoid/human_bandit_alt.png")
		h_frames = marker.get_meta("h_frames", 4)
		v_frames = marker.get_meta("v_frames", 1)

	var sprite_texture: Texture2D = load(sprite_path)
	if not sprite_texture:
		push_error("[BanditHideoutL2] Failed to load sprite: %s" % sprite_path)
		return

	# Spawn slightly above marker position so CharacterBody3D settles on floor
	var spawn_pos: Vector3 = marker.global_position + Vector3(0, 0.5, 0)

	var enemy = EnemyBase.spawn_billboard_enemy(
		self,
		spawn_pos,
		enemy_data_path,
		sprite_texture,
		h_frames,
		v_frames
	)

	if enemy:
		enemy.add_to_group("enemies")
		# Add to quest objective tracking groups
		if is_boss or "bandit_leader" in enemy_data_path:
			enemy.add_to_group("bandit_leader")
			enemy.add_to_group("bosses")
		elif "dark_general" in enemy_data_path:
			enemy.add_to_group("dark_general")
			enemy.add_to_group("bosses")
		else:
			enemy.add_to_group("human_bandit")


func _setup_doors() -> void:
	# Look for pre-placed door markers in scene
	# Expected structure: DoorPositions/Marker3D nodes with metadata

	if not door_positions:
		door_positions = get_node_or_null("DoorPositions")

	if not door_positions:
		return

	var doors_container := Node3D.new()
	doors_container.name = "Doors"
	add_child(doors_container)

	var door_count := 0
	for marker in door_positions.get_children():
		if marker is Marker3D or marker is Node3D:
			_spawn_door_at_marker(marker, doors_container)
			door_count += 1

	print("[BanditHideoutL2] Spawned %d doors from markers" % door_count)


func _spawn_door_at_marker(marker: Node3D, parent: Node3D) -> void:
	var target_scene: String = marker.get_meta("target_scene", "")
	var spawn_id: String = marker.get_meta("spawn_id", "default")
	var door_label: String = marker.get_meta("door_label", "Door")
	var show_frame: bool = marker.get_meta("show_frame", true)

	if target_scene.is_empty():
		push_warning("[BanditHideoutL2] Door marker %s has no target_scene" % marker.name)
		return

	var door := ZoneDoor.spawn_door(
		parent,
		marker.global_position,
		target_scene,
		spawn_id,
		door_label,
		show_frame
	)

	if door:
		door.rotation = marker.rotation


func _setup_chests() -> void:
	# Look for pre-placed chest markers in scene
	# Expected structure: ChestPositions/Marker3D nodes with metadata

	if not chest_positions:
		chest_positions = get_node_or_null("ChestPositions")

	if not chest_positions:
		return

	var chest_count := 0
	for marker in chest_positions.get_children():
		if marker is Marker3D or marker is Node3D:
			_spawn_chest_at_marker(marker)
			chest_count += 1

	print("[BanditHideoutL2] Spawned %d chests from markers" % chest_count)


func _spawn_chest_at_marker(marker: Node3D) -> void:
	var chest_id: String = marker.get_meta("chest_id", "chest_%s" % marker.name)
	var chest_name: String = marker.get_meta("chest_name", "Chest")
	var is_locked: bool = marker.get_meta("is_locked", false)
	var lock_difficulty: int = marker.get_meta("lock_difficulty", 10)
	var is_persistent: bool = marker.get_meta("is_persistent", false)
	var loot_tier: String = marker.get_meta("loot_tier", "common")

	# Use Chest.spawn_chest() static factory method
	var chest := Chest.spawn_chest(
		self,
		marker.global_position,
		chest_name,
		is_locked,
		lock_difficulty,
		is_persistent,
		chest_id
	)

	if chest:
		chest.rotation = marker.rotation
		# Setup loot based on tier
		var tier: LootTables.LootTier = _get_loot_tier(loot_tier)
		chest.setup_with_loot(tier)


func _get_loot_tier(tier_name: String) -> LootTables.LootTier:
	match tier_name.to_lower():
		"junk":
			return LootTables.LootTier.JUNK
		"common":
			return LootTables.LootTier.COMMON
		"uncommon":
			return LootTables.LootTier.UNCOMMON
		"rare":
			return LootTables.LootTier.RARE
		"epic":
			return LootTables.LootTier.EPIC
		"legendary":
			return LootTables.LootTier.LEGENDARY
		_:
			return LootTables.LootTier.COMMON


func _setup_navigation() -> void:
	# Bake navigation if NavigationRegion3D exists
	var nav_region := get_node_or_null("NavigationRegion3D") as NavigationRegion3D
	if nav_region and nav_region.navigation_mesh:
		nav_region.bake_navigation_mesh()
		print("[BanditHideoutL2] Navigation mesh baked")
